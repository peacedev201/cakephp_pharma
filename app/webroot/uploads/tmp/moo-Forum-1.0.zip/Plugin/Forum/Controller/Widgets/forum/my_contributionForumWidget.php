<?php
App::uses('Widget','Controller/Widgets');

class my_contributionForumWidget extends Widget {
    public function beforeRender(Controller $controller) {

    }
}