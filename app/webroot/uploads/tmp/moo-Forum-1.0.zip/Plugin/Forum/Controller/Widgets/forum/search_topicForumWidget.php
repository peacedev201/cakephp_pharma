<?php
App::uses('Widget','Controller/Widgets');

class search_topicForumWidget extends Widget {
    public function beforeRender(Controller $controller) {

    }
}