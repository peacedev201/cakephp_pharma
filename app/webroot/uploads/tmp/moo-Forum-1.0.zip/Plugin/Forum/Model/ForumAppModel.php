<?php 
App::uses('AppModel', 'Model');
class ForumAppModel extends AppModel{
    
}