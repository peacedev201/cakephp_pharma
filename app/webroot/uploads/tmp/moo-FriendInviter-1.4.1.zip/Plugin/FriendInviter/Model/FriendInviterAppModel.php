<?php 
App::uses('AppModel', 'Model');
class FriendInviterAppModel extends AppModel{
    
}