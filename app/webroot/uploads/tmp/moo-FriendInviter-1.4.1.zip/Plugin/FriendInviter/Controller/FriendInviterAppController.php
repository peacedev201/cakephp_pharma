<?php 
App::uses('AppController', 'Controller');
class FriendInviterAppController extends AppController{
    
}