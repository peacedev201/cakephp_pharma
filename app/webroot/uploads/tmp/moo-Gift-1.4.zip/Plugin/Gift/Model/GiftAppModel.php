<?php 
App::uses('AppModel', 'Model');
class GiftAppModel extends AppModel{
    
}