<?php
/**
 * mooSocial - The Web 2.0 Social Network Software
 * @website: http://www.moosocial.com
 */
App::uses('Group', 'Group.Model');

class GroupFixture extends CakeTestFixture {

    public $import = array('model' => 'Group.Group', 'records' => true);

}
