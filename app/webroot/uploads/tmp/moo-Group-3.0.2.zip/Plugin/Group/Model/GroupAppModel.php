<?php 

/*
 * Copyright (c) SocialLOFT LLC
 * mooSocial - The Web 2.0 Social Network Software
 * @website: http://www.moosocial.com
 * @author: mooSocial
 * @license: https://moosocial.com/license/
 */

App::uses('AppModel', 'Model');
class GroupAppModel extends AppModel{
    public $plugin = 'Group';   
}