<?php 
App::uses('AppController', 'Controller');
class ReactionAppController extends AppController{
    
}