-- delete table
DROP TABLE IF EXISTS `{PREFIX}reactions`;

ALTER TABLE `{PREFIX}likes` DROP `reaction`;