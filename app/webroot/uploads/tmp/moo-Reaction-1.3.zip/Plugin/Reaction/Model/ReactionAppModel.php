<?php 
App::uses('AppModel', 'Model');
class ReactionAppModel extends AppModel{
    public $plugin = 'Reaction';
    public $validationDomain = 'reaction';
}